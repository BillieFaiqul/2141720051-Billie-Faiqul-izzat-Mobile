import 'package:billie_s_application3/core/app_export.dart';
import 'package:billie_s_application3/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class OnBoardingScreen extends StatelessWidget {
  const OnBoardingScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 35.h, vertical: 46.v),
                child: Column(children: [
                  SizedBox(height: 42.v),
                  CustomImageView(
                      imagePath: ImageConstant.imgGroupIndigo900,
                      height: 239.v,
                      width: 210.h),
                  SizedBox(height: 28.v),
                  Text("Scan KTP untuk Memulai",
                      style: theme.textTheme.headlineSmall),
                  SizedBox(height: 14.v),
                  Container(
                      width: 284.h,
                      margin: EdgeInsets.only(left: 7.h, right: 13.h),
                      child: Text(
                          "Selanjutnya, lakukanlah langkah sederhana dengan melakukan scan KTP Anda untuk memulai perjalanan membaca yang tak terbatas.",
                          maxLines: 4,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: theme.textTheme.bodyMedium)),
                  Spacer(),
                  Padding(
                      padding: EdgeInsets.symmetric(horizontal: 12.h),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                                padding:
                                    EdgeInsets.only(top: 16.v, bottom: 19.v),
                                child: Text("Lewati",
                                    style: theme.textTheme.bodyLarge)),
                            Spacer(flex: 53),
                            Container(
                                height: 10.v,
                                margin: EdgeInsets.symmetric(vertical: 25.v),
                                child: AnimatedSmoothIndicator(
                                    activeIndex: 0,
                                    count: 4,
                                    effect: ScrollingDotsEffect(
                                        spacing: 7,
                                        activeDotColor: appTheme.indigo900,
                                        dotColor: appTheme.blueGray100,
                                        dotHeight: 10.v,
                                        dotWidth: 10.h))),
                            Spacer(flex: 46),
                            CustomIconButton(
                                height: 60.adaptSize,
                                width: 60.adaptSize,
                                padding: EdgeInsets.all(18.h),
                                onTap: () {
                                  onTapBtnArrowLeft(context);
                                },
                                child: CustomImageView(
                                    imagePath: ImageConstant.imgArrowLeft))
                          ]))
                ]))));
  }

  /// Navigates to the onBoardingScreenTwoScreen when the action is triggered.
  onTapBtnArrowLeft(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.onBoardingScreenTwoScreen);
  }
}
