import 'package:billie_s_application3/core/app_export.dart';
import 'package:billie_s_application3/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class OnBoardingScreenTwoScreen extends StatelessWidget {
  const OnBoardingScreenTwoScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 17.h,
            vertical: 51.v,
          ),
          child: Column(
            children: [
              SizedBox(height: 37.v),
              _buildOnBoardingStack(context),
              SizedBox(height: 42.v),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "Jelajahi dan Pinjam Buku",
                  style: theme.textTheme.headlineSmall,
                ),
              ),
              SizedBox(height: 11.v),
              Container(
                width: 300.h,
                margin: EdgeInsets.only(
                  left: 17.h,
                  right: 23.h,
                ),
                child: Text(
                  "Sekarang, Anda siap untuk menjelajahi koleksi buku kami yang kaya dan beragam. Dengan sekali sentuhan, temukan buku-buku terbaru, klasik, atau sesuai dengan minat Anda.",
                  maxLines: 4,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodyMedium,
                ),
              ),
              Spacer(),
              Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: EdgeInsets.only(right: 18.h),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        height: 10.v,
                        margin: EdgeInsets.only(
                          top: 30.v,
                          bottom: 20.v,
                        ),
                        child: AnimatedSmoothIndicator(
                          activeIndex: 0,
                          count: 4,
                          effect: ScrollingDotsEffect(
                            spacing: 7,
                            activeDotColor: appTheme.indigo900,
                            dotColor: appTheme.blueGray100,
                            dotHeight: 10.v,
                            dotWidth: 10.h,
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 57.h),
                        child: CustomIconButton(
                          height: 60.adaptSize,
                          width: 60.adaptSize,
                          padding: EdgeInsets.all(18.h),
                          child: CustomImageView(
                            imagePath: ImageConstant.imgArrowLeft,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildOnBoardingStack(BuildContext context) {
    return Container(
      height: 229.v,
      width: 310.h,
      padding: EdgeInsets.symmetric(
        horizontal: 15.h,
        vertical: 7.v,
      ),
      decoration: BoxDecoration(
        image: DecorationImage(
          image: fs.Svg(
            ImageConstant.imgGroup10,
          ),
          fit: BoxFit.cover,
        ),
      ),
      child: Stack(
        alignment: Alignment.bottomLeft,
        children: [
          Align(
            alignment: Alignment.center,
            child: Container(
              margin: EdgeInsets.only(right: 2.h),
              padding: EdgeInsets.symmetric(
                horizontal: 15.h,
                vertical: 21.v,
              ),
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: fs.Svg(
                    ImageConstant.imgGroup5,
                  ),
                  fit: BoxFit.cover,
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Padding(
                    padding: EdgeInsets.only(right: 14.h),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomImageView(
                          imagePath: ImageConstant.imgUser,
                          height: 28.adaptSize,
                          width: 28.adaptSize,
                          margin: EdgeInsets.only(top: 22.v),
                        ),
                        CustomImageView(
                          imagePath: ImageConstant.imgUserLightBlue300,
                          height: 32.v,
                          width: 56.h,
                          margin: EdgeInsets.only(
                            left: 25.h,
                            bottom: 19.v,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 47.v),
                  CustomImageView(
                    imagePath: ImageConstant.imgContrast,
                    height: 28.adaptSize,
                    width: 28.adaptSize,
                  ),
                  SizedBox(height: 13.v),
                ],
              ),
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgGroupIndigoA400,
            height: 176.v,
            width: 193.h,
            alignment: Alignment.bottomLeft,
            margin: EdgeInsets.only(left: 14.h),
          ),
        ],
      ),
    );
  }
}
