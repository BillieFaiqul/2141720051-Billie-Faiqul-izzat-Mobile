import 'package:billie_s_application3/core/app_export.dart';
import 'package:billie_s_application3/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class OnBoardingScreenOneScreen extends StatelessWidget {
  const OnBoardingScreenOneScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 20.h, vertical: 46.v),
                child: Column(children: [
                  SizedBox(height: 88.v),
                  CustomImageView(
                      imagePath: ImageConstant.imgGroup,
                      height: 174.v,
                      width: 317.h,
                      alignment: Alignment.centerLeft),
                  SizedBox(height: 51.v),
                  Text("Selamat Datang", style: theme.textTheme.headlineSmall),
                  SizedBox(height: 10.v),
                  Container(
                      width: 325.h,
                      margin: EdgeInsets.only(left: 7.h, right: 3.h),
                      child: Text(
                          "Selamat datang di ScanBorrow, teman pembaca! Kami hadir untuk membuat pengalaman peminjaman buku menjadi lebih mudah dan menyenangkan.",
                          maxLines: 4,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: theme.textTheme.bodyMedium)),
                  Spacer(),
                  Padding(
                      padding: EdgeInsets.symmetric(horizontal: 27.h),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                                padding:
                                    EdgeInsets.only(top: 16.v, bottom: 19.v),
                                child: Text("Lewati",
                                    style: theme.textTheme.bodyLarge)),
                            Spacer(flex: 53),
                            Container(
                                height: 10.v,
                                margin: EdgeInsets.symmetric(vertical: 25.v),
                                child: AnimatedSmoothIndicator(
                                    activeIndex: 0,
                                    count: 4,
                                    effect: ScrollingDotsEffect(
                                        spacing: 8,
                                        activeDotColor: appTheme.indigo900,
                                        dotColor: appTheme.blueGray100,
                                        dotHeight: 10.v,
                                        dotWidth: 10.h))),
                            Spacer(flex: 46),
                            CustomIconButton(
                                height: 60.adaptSize,
                                width: 60.adaptSize,
                                padding: EdgeInsets.all(18.h),
                                onTap: () {
                                  onTapBtnArrowLeft(context);
                                },
                                child: CustomImageView(
                                    imagePath: ImageConstant.imgArrowLeft))
                          ]))
                ]))));
  }

  /// Navigates to the onBoardingScreen when the action is triggered.
  onTapBtnArrowLeft(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.onBoardingScreen);
  }
}
