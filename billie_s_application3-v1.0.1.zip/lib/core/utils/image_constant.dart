class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Splash Screen images
  static String imgLogo1 = '$imagePath/img_logo_1.png';

  // On Boarding Screen One images
  static String imgGroup = '$imagePath/img_group.svg';

  // On Boarding Screen images
  static String imgGroupIndigo900 = '$imagePath/img_group_indigo_900.svg';

  // On Boarding Screen Two images
  static String imgGroup10 = '$imagePath/img_group_10.svg';

  static String imgGroup5 = '$imagePath/img_group_5.svg';

  static String imgUser = '$imagePath/img_user.svg';

  static String imgUserLightBlue300 = '$imagePath/img_user_light_blue_300.svg';

  static String imgContrast = '$imagePath/img_contrast.svg';

  static String imgGroupIndigoA400 = '$imagePath/img_group_indigo_a400.svg';

  // Common images
  static String imgArrowLeft = '$imagePath/img_arrow_left.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
