import 'package:flutter/material.dart';
import 'package:billie_s_application3/presentation/splash_screen/splash_screen.dart';
import 'package:billie_s_application3/presentation/on_boarding_screen_one_screen/on_boarding_screen_one_screen.dart';
import 'package:billie_s_application3/presentation/on_boarding_screen/on_boarding_screen.dart';
import 'package:billie_s_application3/presentation/on_boarding_screen_two_screen/on_boarding_screen_two_screen.dart';
import 'package:billie_s_application3/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String splashScreen = '/splash_screen';

  static const String onBoardingScreenOneScreen =
      '/on_boarding_screen_one_screen';

  static const String onBoardingScreen = '/on_boarding_screen';

  static const String onBoardingScreenTwoScreen =
      '/on_boarding_screen_two_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    splashScreen: (context) => SplashScreen(),
    onBoardingScreenOneScreen: (context) => OnBoardingScreenOneScreen(),
    onBoardingScreen: (context) => OnBoardingScreen(),
    onBoardingScreenTwoScreen: (context) => OnBoardingScreenTwoScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
